from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

def add_item(name):
    conn = sqlite3.connect('digitalshop.db')
    cursor = conn.cursor()

    cursor.execute('SELECT amount FROM items WHERE name = ?', (name,))  # Check if the item already exists in the database
    result = cursor.fetchone()

    if result:  # If the item exists, increment its amount
        cursor.execute('UPDATE items SET amount = amount + 1 WHERE name = ?', (name,))
    else:  # If the item doesn't exist, add it with amount 1
        cursor.execute('INSERT INTO items (name, amount) VALUES (?, ?)', (name, 1))
    
    conn.commit()
    conn.close()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/cart')
def cart():
    conn = sqlite3.connect('digitalshop.db')
    cursor = conn.cursor()
    cursor.execute('SELECT name, amount FROM items')  # Get all items and their amounts
    items = cursor.fetchall()  # Fetch all results
    conn.close()  
    return render_template('cart.html', items=items)  # Pass items to the template

@app.route('/add', methods=['POST'])
def add():
    item_name = request.form['name']  # Get the food name from the button clicked
    add_item(item_name)
    return redirect(url_for('index'))

@app.route('/order', methods=['POST'])
def order_cart():
    conn = sqlite3.connect('digitalshop.db')
    conn.execute('DELETE FROM items')  # Deletes all rows from the items table
    conn.commit()  # Commit the changes
    conn.close()
    return redirect(url_for('cart'))  # Redirect to the main page after clearing

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080, debug=True)